#!/usr/bin/env bash
echo "MWES was restarted sucessfully" | /usr/bin/mail -a "FROM: systemd@systemd.com" -s "Restarted MWES service on {domain}" {postmaster@example.com}
